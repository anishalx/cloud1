#!/usr/bin/env python3
"""Seed the local LocalStack account with a small, deliberately weak cloud."""
from __future__ import annotations

import json
import os
import sys
import time

import boto3
from botocore.exceptions import BotoCoreError, ClientError

ENDPOINT = os.getenv("AWS_ENDPOINT_URL", "http://localstack:4566")
REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
CLOUDFOX_FLAG = os.getenv("CLOUDFOX_FLAG", "CG{missing-cloudfox-flag}")
ACCESS_KEY = os.getenv("AWS_ACCESS_KEY_ID", "test")
SECRET_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "test")

BUCKET = "cloudgoat-public-backups"
PRIVATE_BUCKET = "cloudgoat-private-artifacts"


def client(service: str):
    return boto3.client(
        service,
        endpoint_url=ENDPOINT,
        region_name=REGION,
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
    )


def wait_for_cloud() -> None:
    sts = client("sts")
    last_error: Exception | None = None
    for attempt in range(1, 61):
        try:
            sts.get_caller_identity()
            print(f"LocalStack is ready after {attempt} attempt(s)")
            return
        except (BotoCoreError, ClientError) as exc:
            last_error = exc
            time.sleep(2)
    raise SystemExit(f"LocalStack did not become ready: {last_error}")


def create_user(iam, name: str) -> None:
    try:
        iam.create_user(UserName=name)
        print(f"created IAM user {name}")
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "EntityAlreadyExists":
            raise


def create_role(iam, name: str, trust: dict) -> None:
    try:
        iam.create_role(RoleName=name, AssumeRolePolicyDocument=json.dumps(trust))
        print(f"created IAM role {name}")
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "EntityAlreadyExists":
            raise


def put_user_policy(iam, user: str, name: str, document: dict) -> None:
    iam.put_user_policy(
        UserName=user,
        PolicyName=name,
        PolicyDocument=json.dumps(document),
    )


def seed_iam() -> None:
    iam = client("iam")

    create_user(iam, "cloudgoat-dev")
    create_user(iam, "intern")

    admin_trust = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"AWS": "arn:aws:iam::000000000000:root"},
                "Action": "sts:AssumeRole",
            }
        ],
    }
    create_role(iam, "cloudgoat-admin-role", admin_trust)
    try:
        iam.attach_role_policy(
            RoleName="cloudgoat-admin-role",
            PolicyArn="arn:aws:iam::aws:policy/AdministratorAccess",
        )
    except ClientError as exc:
        if exc.response["Error"]["Code"] not in {"NoSuchEntity", "LimitExceeded"}:
            raise

    put_user_policy(
        iam,
        "intern",
        "cloudgoat-privesc",
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": ["iam:PassRole", "sts:AssumeRole"],
                    "Resource": "*",
                }
            ],
        },
    )
    put_user_policy(
        iam,
        "cloudgoat-dev",
        "cloudgoat-read",
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": ["s3:ListAllMyBuckets", "s3:GetObject", "s3:ListBucket"],
                    "Resource": "*",
                }
            ],
        },
    )

    try:
        iam.create_access_key(UserName="cloudgoat-dev")
    except ClientError:
        pass


def seed_s3() -> None:
    s3 = client("s3")

    for bucket in (BUCKET, PRIVATE_BUCKET):
        try:
            s3.create_bucket(Bucket=bucket)
            print(f"created bucket {bucket}")
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code not in {"BucketAlreadyOwnedByYou", "BucketAlreadyExists"}:
                raise

    s3.put_object(
        Bucket=BUCKET,
        Key="prod/cloudfox.flag",
        Body=(CLOUDFOX_FLAG + "\n").encode(),
        ContentType="text/plain",
    )
    s3.put_object(
        Bucket=BUCKET,
        Key="prod/backup-notes.txt",
        Body=b"Nightly backup. Do not make this bucket public.\n",
        ContentType="text/plain",
    )
    s3.put_object(
        Bucket=PRIVATE_BUCKET,
        Key="prod/db-dump.enc",
        Body=b"not a real database dump\n",
        ContentType="application/octet-stream",
    )

    public_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "PublicRead",
                "Effect": "Allow",
                "Principal": "*",
                "Action": ["s3:GetObject"],
                "Resource": [f"arn:aws:s3:::{BUCKET}/*"],
            }
        ],
    }
    try:
        s3.put_bucket_policy(Bucket=BUCKET, Policy=json.dumps(public_policy))
    except ClientError as exc:
        print(f"bucket policy not applied: {exc}", file=sys.stderr)


def seed_other_services() -> None:
    secrets = client("secretsmanager")
    try:
        secrets.create_secret(
            Name="prod/cloudgoat/db",
            Description="CloudGate production database",
            SecretString=json.dumps(
                {
                    "username": "cloudgate",
                    "password": "local-only-not-real",
                    "note": "CloudFox can enumerate this secret name.",
                }
            ),
        )
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ResourceExistsException":
            raise

    # The community LocalStack image does not implement ECR.  The registry
    # challenge is served by the in-cluster toy registry instead, so skip it.
    sqs = client("sqs")
    try:
        sqs.create_queue(QueueName="cloudgoat-jobs")
    except (BotoCoreError, ClientError) as exc:
        print(f"sqs seed skipped: {exc}", file=sys.stderr)


def main() -> int:
    wait_for_cloud()
    seed_iam()
    seed_s3()
    seed_other_services()
    print("LocalStack seed complete")
    print(f"CloudFox flag object: s3://{BUCKET}/prod/cloudfox.flag")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
