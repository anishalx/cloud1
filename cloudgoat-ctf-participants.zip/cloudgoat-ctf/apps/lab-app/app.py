#!/usr/bin/env python3
"""Intentionally vulnerable CloudGate application used by the lab.

This image is reused for several Kubernetes Goat scenarios.  APP_MODE changes
the routes, not the security posture: every mode is deliberately unsuitable for
production.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import socket
import tarfile
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from flask import Flask, Response, jsonify, render_template, request

app = Flask(__name__)
APP_MODE = os.getenv("APP_MODE", "console").strip().lower()
FLAG = os.getenv("CLOUDGOAT_FLAG", "CG{missing-flag}")
REGISTRY_FLAG = os.getenv("REGISTRY_FLAG", FLAG)
LAYERS_FLAG = os.getenv("LAYERS_FLAG", FLAG)
POD_NAME = os.getenv("POD_NAME", socket.gethostname())
POD_NAMESPACE = os.getenv("POD_NAMESPACE", "cloudgoat")
NODE_NAME = os.getenv("NODE_NAME", "unknown")

SERVICE_LINKS = [
    ("Public console", "http://127.0.0.1:30080/", "NodePort"),
    ("Internal proxy", "http://127.0.0.1:1232/", "port-forward"),
    ("Environment app", "http://127.0.0.1:1237/env", "port-forward"),
    ("Private registry", "http://127.0.0.1:30085/v2/_catalog", "NodePort"),
]


@app.after_request
def add_headers(response: Response) -> Response:
    response.headers["X-CloudGate-Mode"] = APP_MODE
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.get("/")
def index():
    context = {
        "mode": APP_MODE,
        "pod": POD_NAME,
        "namespace": POD_NAMESPACE,
        "node": NODE_NAME,
        "links": SERVICE_LINKS,
        "flag": FLAG if APP_MODE == "nodeport" else None,
        "internal_targets": [
            "http://metadata-db:8080/secret",
            "http://billing-api.billing.svc.cluster.local:8080/secret",
            "http://kubernetes.default.svc/api",
        ]
        if APP_MODE == "proxy"
        else [],
    }
    return render_template("index.html", **context)


@app.get("/status")
def status():
    body = {
        "service": "cloudgate",
        "mode": APP_MODE,
        "pod": POD_NAME,
        "namespace": POD_NAMESPACE,
        "node": NODE_NAME,
        "time": datetime.now(timezone.utc).isoformat(),
    }
    if APP_MODE == "nodeport":
        # Deliberate: the exposed service leaks its environment.
        body["env"] = dict(os.environ)
    return jsonify(body)


@app.get("/env")
def env_route():
    if APP_MODE != "env":
        return jsonify({"error": "not enabled on this workload"}), 404
    return jsonify(dict(os.environ))


@app.get("/secret")
def secret():
    if APP_MODE not in {"metadata", "billing"}:
        return jsonify({"error": "not found"}), 404
    return jsonify(
        {
            "service": APP_MODE,
            "flag": FLAG,
            "hint": "This service should not have been reachable from the proxy.",
        }
    )


@app.get("/fetch")
def fetch():
    if APP_MODE != "proxy":
        return jsonify({"error": "not found"}), 404

    target = request.args.get("url", "").strip()
    if not target:
        return jsonify(
            {
                "usage": "/fetch?url=http://metadata-db:8080/secret",
                "note": "The proxy accepts any URL, including cluster DNS names.",
            }
        )

    parsed = urlparse(target)
    if parsed.scheme not in {"http", "https"}:
        return jsonify({"error": "only http and https are supported"}), 400

    try:
        req = Request(target, headers={"User-Agent": "CloudGate-InternalProxy/1.0"})
        with urlopen(req, timeout=5) as upstream:
            data = upstream.read(128 * 1024)
            content_type = upstream.headers.get("Content-Type", "text/plain")
            return Response(data, status=upstream.status, content_type=content_type)
    except HTTPError as exc:
        return Response(exc.read(), status=exc.code, content_type="text/plain")
    except (URLError, TimeoutError, socket.timeout) as exc:
        return jsonify({"error": str(exc), "target": target}), 502


@app.get("/runtime")
def runtime():
    if APP_MODE != "health":
        return jsonify({"error": "not found"}), 404
    paths = ["/host-runtime", "/host-flags", "/host-system"]
    result = {}
    for path in paths:
        try:
            result[path] = sorted(os.listdir(path))
        except OSError as exc:
            result[path] = f"unavailable: {exc}"
    return jsonify({"mounts": result, "note": "Host paths are mounted into this pod."})


@app.get("/host-tree")
def host_tree():
    if APP_MODE != "monitor":
        return jsonify({"error": "not found"}), 404
    return jsonify(
        {
            "mounted": "/host-system",
            "suggested": "/host-system/var/lib/cloudgoat/node.flag",
            "note": "A privileged pod with hostPath / can read the node filesystem.",
        }
    )


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "mode": APP_MODE})


# ---------------------------------------------------------------------------
# A tiny read-only OCI distribution API.  It is not a real registry: it serves
# two hand-built manifests so the lab can demonstrate registry enumeration and
# secrets in image history without requiring a push at setup time.
# ---------------------------------------------------------------------------


def _digest(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _empty_layer() -> tuple[bytes, str]:
    tar_bytes = io.BytesIO()
    with tarfile.open(fileobj=tar_bytes, mode="w") as tar:
        info = tarfile.TarInfo("cloudgoat.txt")
        payload = b"CloudGate lab layer\n"
        info.size = len(payload)
        info.mtime = 0
        tar.addfile(info, io.BytesIO(payload))
    uncompressed = tar_bytes.getvalue()
    compressed = gzip.compress(uncompressed, mtime=0)
    return compressed, _digest(uncompressed)


class ToyRegistry:
    def __init__(self) -> None:
        self.repos: dict[str, dict[str, object]] = {}
        self.blobs: dict[str, bytes] = {}
        self._build()

    def _add_image(
        self,
        name: str,
        env: list[str],
        history: list[str],
        tag: str = "latest",
    ) -> None:
        layer, diff_id = _empty_layer()
        layer_digest = _digest(layer)
        self.blobs[layer_digest] = layer

        config_obj = {
            "architecture": "amd64",
            "os": "linux",
            "created": "2024-01-01T00:00:00Z",
            "config": {
                "Env": env,
                "Cmd": ["python", "-m", "http.server", "8000"],
                "Labels": {
                    "org.opencontainers.image.title": "cloudgate-leaky-app",
                    "org.opencontainers.image.vendor": "CloudGate Labs",
                },
            },
            "rootfs": {"type": "layers", "diff_ids": [diff_id]},
            "history": [
                {"created": "2024-01-01T00:00:00Z", "created_by": item}
                for item in history
            ],
        }
        config_bytes = json.dumps(config_obj, indent=2).encode("utf-8")
        config_digest = _digest(config_bytes)
        self.blobs[config_digest] = config_bytes

        manifest = {
            "schemaVersion": 2,
            "mediaType": "application/vnd.docker.distribution.manifest.v2+json",
            "config": {
                "mediaType": "application/vnd.docker.container.image.v1+json",
                "size": len(config_bytes),
                "digest": config_digest,
            },
            "layers": [
                {
                    "mediaType": "application/vnd.docker.image.rootfs.diff.tar.gzip",
                    "size": len(layer),
                    "digest": layer_digest,
                }
            ],
        }
        manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
        manifest_digest = _digest(manifest_bytes)
        self.blobs[manifest_digest] = manifest_bytes

        self.repos[name] = {
            "tags": {tag: manifest_bytes},
            "manifest_digest": manifest_digest,
        }

    def _build(self) -> None:
        self._add_image(
            "cloudgoat/leaky-app",
            [
                "PATH=/usr/local/bin:/usr/bin:/bin",
                "AWS_ACCESS_KEY_ID=" + os.getenv("AWS_ACCESS_KEY_ID", "AKIAEXAMPLE"),
                "AWS_SECRET_ACCESS_KEY="
                + os.getenv("AWS_SECRET_ACCESS_KEY", "example-secret"),
                "CLOUDGOAT_REGISTRY_FLAG=" + REGISTRY_FLAG,
            ],
            [
                "ADD . /app # build context",
                "RUN pip install -r requirements.txt",
                "ENV CLOUDGOAT_REGISTRY_FLAG=" + REGISTRY_FLAG,
            ],
        )
        self._add_image(
            "cloudgoat/hidden-layers",
            ["PATH=/usr/local/bin:/usr/bin:/bin"],
            [
                "FROM python:3.11-slim",
                f"RUN echo '{LAYERS_FLAG}' > /tmp/cloudgoat.flag",
                "RUN rm -f /tmp/cloudgoat.flag",
                "CMD ['python', '-m', 'http.server']",
            ],
        )

    def catalog(self) -> dict:
        return {"repositories": sorted(self.repos)}


REGISTRY = ToyRegistry() if APP_MODE == "registry" else None


@app.get("/v2/")
def registry_v2():
    if APP_MODE != "registry":
        return jsonify({"error": "not found"}), 404
    response = jsonify({})
    response.headers["Docker-Distribution-Api-Version"] = "registry/2.0"
    return response


@app.get("/v2/_catalog")
def registry_catalog():
    if REGISTRY is None:
        return jsonify({"error": "not found"}), 404
    response = jsonify(REGISTRY.catalog())
    response.headers["Docker-Distribution-Api-Version"] = "registry/2.0"
    return response


@app.get("/v2/<path:repo>/tags/list")
def registry_tags(repo: str):
    if REGISTRY is None or repo not in REGISTRY.repos:
        return jsonify({"errors": [{"code": "NAME_UNKNOWN"}]}), 404
    return jsonify({"name": repo, "tags": sorted(REGISTRY.repos[repo]["tags"])})


@app.route("/v2/<path:repo>/manifests/<tag>", methods=["GET", "HEAD"])
def registry_manifest(repo: str, tag: str):
    if REGISTRY is None or repo not in REGISTRY.repos:
        return jsonify({"errors": [{"code": "NAME_UNKNOWN"}]}), 404
    entry = REGISTRY.repos[repo]
    manifest = entry["tags"].get(tag)
    if manifest is None:
        return jsonify({"errors": [{"code": "MANIFEST_UNKNOWN"}]}), 404

    response = Response(
        manifest if request.method == "GET" else b"",
        content_type="application/vnd.docker.distribution.manifest.v2+json",
    )
    response.headers["Docker-Content-Digest"] = entry["manifest_digest"]
    response.headers["Docker-Distribution-Api-Version"] = "registry/2.0"
    return response


@app.get("/v2/<path:repo>/blobs/<digest>")
def registry_blob(repo: str, digest: str):
    if REGISTRY is None or digest not in REGISTRY.blobs:
        return jsonify({"errors": [{"code": "BLOB_UNKNOWN"}]}), 404
    return Response(REGISTRY.blobs[digest], content_type="application/octet-stream")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    app.run(host="0.0.0.0", port=port, debug=False)
