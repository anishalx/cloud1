#!/usr/bin/env python3
"""Build-code service. The interesting artifact is /app/.git, not this page."""
from __future__ import annotations

import os

from flask import Flask, jsonify, render_template

app = Flask(__name__)
POD = os.getenv("POD_NAME", "build-code")


@app.get("/")
def index():
    return render_template("index.html", pod=POD)


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "service": "build-code"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
