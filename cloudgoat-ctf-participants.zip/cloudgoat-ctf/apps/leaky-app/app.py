#!/usr/bin/env python3
"""A deliberately old Flask app for image-scanning exercises."""
from __future__ import annotations

import os

from flask import Flask, jsonify

app = Flask(__name__)


@app.get("/")
def index():
    return jsonify(
        {
            "service": "cloudgate-leaky-app",
            "status": "running",
            "note": "This image pins old packages on purpose.",
        }
    )


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
