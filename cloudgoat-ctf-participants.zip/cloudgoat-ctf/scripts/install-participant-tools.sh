#!/usr/bin/env bash
# Install every participant tool EXCEPT Docker / Docker Compose.
# Kali participants are expected to arrive with a working Docker Engine and
# Compose v2 plugin already installed; this script verifies that but does not
# install or change them.
set -euo pipefail

SUDO=""
if [[ "${EUID}" -ne 0 ]]; then
  SUDO="sudo"
fi

ARCH="$(dpkg --print-architecture 2>/dev/null || uname -m)"
case "$ARCH" in
  amd64|x86_64)
    GO_ARCH="amd64"
    AWS_ARCH="x86_64"
    ;;
  arm64|aarch64)
    GO_ARCH="arm64"
    AWS_ARCH="aarch64"
    ;;
  *)
    echo "unsupported architecture: $ARCH" >&2
    exit 1
    ;;
esac

echo "[*] Checking Docker prerequisite (not installing Docker)"
if ! command -v docker >/dev/null || ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker Engine is not running. Install/start Docker on Kali first." >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "ERROR: Docker Compose v2 plugin is missing. Install it on Kali first." >&2
  exit 1
fi

echo "[*] Installing base packages"
$SUDO apt-get update
$SUDO apt-get install -y \
  git curl wget jq unzip tar make ca-certificates \
  python3 python3-pip skopeo kubernetes-helm

echo "[*] Installing AWS CLI v2 if missing"
if ! command -v aws >/dev/null; then
  curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-${AWS_ARCH}.zip" -o /tmp/awscliv2.zip
  unzip -q -o /tmp/awscliv2.zip -d /tmp/awscliv2-install
  $SUDO /tmp/awscliv2-install/aws/install --update
fi

echo "[*] Installing kind and kubectl if missing"
if ! command -v kind >/dev/null; then
  curl -fsSL "https://kind.sigs.k8s.io/dl/v0.33.0/kind-linux-${GO_ARCH}" -o /tmp/kind
  $SUDO install -m 0755 /tmp/kind /usr/local/bin/kind
fi
if ! command -v kubectl >/dev/null; then
  KVER="$(curl -fsSL https://dl.k8s.io/release/stable.txt)"
  curl -fsSL "https://dl.k8s.io/release/${KVER}/bin/linux/${GO_ARCH}/kubectl" -o /tmp/kubectl
  $SUDO install -m 0755 /tmp/kubectl /usr/local/bin/kubectl
fi

echo "[*] Installing Trivy if missing"
if ! command -v trivy >/dev/null; then
  if apt-cache show trivy >/dev/null 2>&1; then
    $SUDO apt-get install -y trivy
  else
    curl -fsSL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh \
      | $SUDO sh -s -- -b /usr/local/bin
  fi
fi

echo "[*] Installing Grype if missing"
if ! command -v grype >/dev/null; then
  curl -fsSL https://raw.githubusercontent.com/anchore/grype/main/install.sh \
    | $SUDO sh -s -- -b /usr/local/bin
fi

echo "[*] Installing Gitleaks if missing"
if ! command -v gitleaks >/dev/null; then
  GITLEAKS_VERSION="$(curl -fsSL https://api.github.com/repos/gitleaks/gitleaks/releases/latest | jq -r .tag_name | sed 's/^v//')"
  curl -fsSL "https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/gitleaks_${GITLEAKS_VERSION}_linux_${GO_ARCH}.tar.gz" \
    -o /tmp/gitleaks.tar.gz
  tar -xzf /tmp/gitleaks.tar.gz -C /tmp gitleaks
  $SUDO install -m 0755 /tmp/gitleaks /usr/local/bin/gitleaks
fi

echo "[*] Installing CloudFox if missing"
if ! command -v cloudfox >/dev/null; then
  CF_VERSION="$(curl -fsSL https://api.github.com/repos/BishopFox/cloudfox/releases/latest | jq -r .tag_name)"
  curl -fsSL "https://github.com/BishopFox/cloudfox/releases/download/${CF_VERSION}/cloudfox-linux-${GO_ARCH}.zip" \
    -o /tmp/cloudfox.zip
  rm -rf /tmp/cloudfox-extract
  unzip -q -o /tmp/cloudfox.zip -d /tmp/cloudfox-extract
  $SUDO install -m 0755 "$(find /tmp/cloudfox-extract -name cloudfox -type f | head -1)" /usr/local/bin/cloudfox
fi

echo "[*] Installing KubeAudit, Popeye, and kube-bench if missing"
install_tarball_binary() {
  local repo="$1" pattern="$2" bin="$3"
  if command -v "$bin" >/dev/null; then
    return 0
  fi
  local version
  version="$(curl -fsSL "https://api.github.com/repos/${repo}/releases/latest" | jq -r .tag_name | sed 's/^v//')"
  local url="https://github.com/${repo}/releases/download/v${version}/${pattern//VERSION/${version}}"
  curl -fsSL "$url" -o "/tmp/${bin}.tar.gz"
  rm -rf "/tmp/${bin}-extract"
  mkdir -p "/tmp/${bin}-extract"
  tar -xzf "/tmp/${bin}.tar.gz" -C "/tmp/${bin}-extract"
  local found
  found="$(find "/tmp/${bin}-extract" -type f -name "$bin" | head -1)"
  if [[ -z "$found" ]]; then
    echo "ERROR: could not find $bin in downloaded archive" >&2
    exit 1
  fi
  $SUDO install -m 0755 "$found" "/usr/local/bin/${bin}"
}

install_tarball_binary "Shopify/kubeaudit" "kubeaudit_VERSION_linux_${GO_ARCH}.tar.gz" "kubeaudit"
install_tarball_binary "derailed/popeye" "popeye_linux_${GO_ARCH}.tar.gz" "popeye"
install_tarball_binary "aquasecurity/kube-bench" "kube-bench_VERSION_linux_${GO_ARCH}.tar.gz" "kube-bench"

echo
echo "[*] Versions (Docker is checked, not installed)"
for tool in docker kind kubectl trivy grype gitleaks cloudfox kubeaudit popeye kube-bench helm skopeo aws jq; do
  if command -v "$tool" >/dev/null; then
    printf '  %-12s ' "$tool"
    if [[ "$tool" == "docker" ]]; then
      docker --version
    else
      "$tool" --version 2>/dev/null | head -1 || true
    fi
  else
    printf '  %-12s missing\n' "$tool"
  fi
done
