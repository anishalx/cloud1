#!/usr/bin/env python3
"""Create/update the `cloudgoat` AWS profile without touching other profiles."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FLAGS = ROOT / "flags" / "flags.json"


def strip_section(text: str, header: str) -> str:
    lines = text.splitlines()
    output: list[str] = []
    skipping = False
    for line in lines:
        if line.strip() == header:
            skipping = True
            continue
        if skipping and line.startswith("[") and line.endswith("]"):
            skipping = False
        if not skipping:
            output.append(line)
    return "\n".join(output).strip() + "\n"


def main() -> int:
    if not FLAGS.exists():
        print("flags/flags.json is missing; run scripts/generate.py first", file=sys.stderr)
        return 1
    values = json.loads(FLAGS.read_text(encoding="utf-8"))
    home = Path.home()
    aws_dir = home / ".aws"
    aws_dir.mkdir(mode=0o700, exist_ok=True)

    config_path = aws_dir / "config"
    credentials_path = aws_dir / "credentials"
    config_text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    credentials_text = (
        credentials_path.read_text(encoding="utf-8") if credentials_path.exists() else ""
    )

    config_text = strip_section(config_text, "[profile cloudgoat]")
    credentials_text = strip_section(credentials_text, "[cloudgoat]")

    config_text += (
        "\n[profile cloudgoat]\n"
        "region = us-east-1\n"
        "output = json\n"
        "endpoint_url = http://127.0.0.1:4566\n"
    )
    credentials_text += (
        "\n[cloudgoat]\n"
        f"aws_access_key_id = {values['aws_access_key_id']}\n"
        f"aws_secret_access_key = {values['aws_secret_access_key']}\n"
    )

    config_path.write_text(config_text.lstrip(), encoding="utf-8")
    credentials_path.write_text(credentials_text.lstrip(), encoding="utf-8")
    os.chmod(config_path, 0o600)
    os.chmod(credentials_path, 0o600)
    print("Updated ~/.aws/config and ~/.aws/credentials with profile 'cloudgoat'.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
