#!/usr/bin/env python3
"""Kubernetes Cloud Goat CTF portal.

Each participant runs their own copy of the lab. There are no teams: the portal
records one participant's email, then tracks that person's progress locally.
Challenge answers are only stored as SHA-256 hashes; plaintext flags never
reach this service.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request

APP_DIR = Path(__file__).resolve().parent
CHALLENGES_FILE = Path(os.getenv("CHALLENGES_FILE", APP_DIR / "challenges.json"))
DATABASE_PATH = Path(os.getenv("DATABASE_PATH", APP_DIR / "data" / "ctf.db"))

app = Flask(__name__)
app.config.update(
    MAX_CONTENT_LENGTH=32 * 1024,
    SEND_FILE_MAX_AGE_DEFAULT=0,
)

with CHALLENGES_FILE.open(encoding="utf-8") as fh:
    CATALOG: list[dict] = json.load(fh)
CATALOG_BY_ID = {item["id"]: item for item in CATALOG}

ATTEMPTS: list[float] = []
ATTEMPT_LIMIT = 40
ATTEMPT_WINDOW = 60.0
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    with db() as conn:
        columns = [row[1] for row in conn.execute("PRAGMA table_info(solves)")]
        if columns and "team_id" in columns:
            # Migrate older team-based labs to the single-participant model.
            conn.executescript(
                """
                DROP TABLE IF EXISTS solves;
                DROP TABLE IF EXISTS teams;
                """
            )
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS participant (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                email TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS solves (
                challenge_id TEXT PRIMARY KEY,
                points INTEGER NOT NULL,
                solved_at TEXT NOT NULL,
                answer_hash TEXT NOT NULL
            );
            """
        )


init_db()


def participant() -> sqlite3.Row | None:
    with db() as conn:
        return conn.execute("SELECT email, created_at FROM participant WHERE id = 1").fetchone()


def set_participant(email: str) -> str:
    email = email.strip().lower()
    if not email or len(email) > 254 or not EMAIL_RE.fullmatch(email):
        raise ValueError("enter a valid email address")
    now = utc_now()
    with db() as conn:
        conn.execute(
            "INSERT INTO participant(id, email, created_at) VALUES(1, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET email = excluded.email",
            (email, now),
        )
    return email


def progress() -> tuple[list[str], int]:
    with db() as conn:
        rows = conn.execute(
            "SELECT challenge_id, points FROM solves ORDER BY solved_at"
        ).fetchall()
    return [row["challenge_id"] for row in rows], sum(row["points"] for row in rows)


def result_rows() -> list[dict]:
    solved, _ = progress()
    solved_set = set(solved)
    with db() as conn:
        rows = conn.execute(
            "SELECT challenge_id, points, solved_at FROM solves ORDER BY solved_at"
        ).fetchall()
    return [
        {
            "challenge_id": row["challenge_id"],
            "title": CATALOG_BY_ID.get(row["challenge_id"], {}).get("title", row["challenge_id"]),
            "points": row["points"],
            "solved_at": row["solved_at"],
        }
        for row in rows
        if row["challenge_id"] in solved_set
    ]


def rate_limited() -> bool:
    now = time.monotonic()
    ATTEMPTS[:] = [t for t in ATTEMPTS if now - t < ATTEMPT_WINDOW]
    if len(ATTEMPTS) >= ATTEMPT_LIMIT:
        return True
    ATTEMPTS.append(now)
    return False


def public_challenge(item: dict) -> dict:
    fields = [
        "id",
        "number",
        "title",
        "category",
        "difficulty",
        "points",
        "tool",
        "summary",
        "objective",
        "hint",
        "answer_hint",
        "answer_type",
    ]
    return {key: item[key] for key in fields if key in item}


def digest(value: str) -> str:
    return hashlib.sha256(value.strip().encode("utf-8")).hexdigest()


def check_answer(challenge: dict, answer: str) -> bool:
    answer = answer.strip()
    if not answer:
        return False
    if challenge.get("answer_type") == "regex":
        pattern = challenge.get("answer_regex", "")
        try:
            return bool(re.fullmatch(pattern, answer, flags=re.IGNORECASE))
        except re.error:
            return False
    return digest(answer) in set(challenge.get("answers_sha256", []))


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "challenges": len(CATALOG), "teams": False})


@app.get("/api/profile")
def profile():
    row = participant()
    return jsonify({"email": row["email"] if row else None, "created_at": row["created_at"] if row else None})


@app.post("/api/profile")
def set_profile():
    body = request.get_json(silent=True) or request.form
    try:
        email = set_participant(str(body.get("email", "")))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify({"ok": True, "email": email})


@app.get("/api/challenges")
def challenges():
    solved, score = progress()
    payload = []
    for item in CATALOG:
        row = public_challenge(item)
        row["solved"] = item["id"] in solved
        payload.append(row)
    return jsonify({"challenges": payload, "score": score, "solved": len(solved)})


@app.get("/api/me")
def me():
    solved, score = progress()
    row = participant()
    return jsonify(
        {
            "email": row["email"] if row else None,
            "solved": solved,
            "score": score,
            "solved_count": len(solved),
            "total": len(CATALOG),
        }
    )


@app.post("/api/submit")
def submit():
    if not participant():
        return jsonify({"error": "enter your email before starting"}), 403
    if rate_limited():
        return jsonify({"error": "too many attempts; wait a minute"}), 429

    body = request.get_json(silent=True) or request.form
    challenge_id = str(body.get("challenge_id", "")).strip()
    answer = str(body.get("answer", "")).strip()
    challenge = CATALOG_BY_ID.get(challenge_id)
    if not challenge:
        return jsonify({"error": "unknown challenge"}), 404
    if not answer:
        return jsonify({"error": "enter a flag"}), 400

    solved, score = progress()
    if challenge_id in solved:
        return jsonify(
            {
                "correct": True,
                "already_solved": True,
                "points": 0,
                "score": score,
                "solved": len(solved),
            }
        )

    if not check_answer(challenge, answer):
        return jsonify({"correct": False, "message": "not the flag for this challenge"})

    try:
        with db() as conn:
            conn.execute(
                "INSERT INTO solves(challenge_id, points, solved_at, answer_hash) "
                "VALUES(?, ?, ?, ?)",
                (challenge_id, challenge["points"], utc_now(), digest(answer)),
            )
    except sqlite3.IntegrityError:
        pass

    solved, score = progress()
    return jsonify(
        {
            "correct": True,
            "message": "accepted",
            "points": challenge["points"],
            "score": score,
            "solved": len(solved),
        }
    )


@app.get("/api/results")
def results():
    row = participant()
    solved, score = progress()
    return jsonify(
        {
            "email": row["email"] if row else None,
            "score": score,
            "solved": len(solved),
            "total": len(CATALOG),
            "challenges": result_rows(),
        }
    )


@app.get("/api/export")
def export():
    row = participant()
    if not row:
        return jsonify({"error": "enter your email before exporting"}), 403
    solved, score = progress()
    rows = result_rows()

    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(["email", "score", "solved", "total", "challenge_id", "title", "points", "solved_at"])
    writer.writerow([row["email"], score, len(solved), len(CATALOG), "", "", "", ""])
    for item in rows:
        writer.writerow(
            [
                row["email"],
                score,
                len(solved),
                len(CATALOG),
                item["challenge_id"],
                item["title"],
                item["points"],
                item["solved_at"],
            ]
        )

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": 'attachment; filename="cloudgoat-results.csv"'},
    )


@app.post("/api/reset")
def reset():
    with db() as conn:
        conn.execute("DELETE FROM solves")
    ATTEMPTS.clear()
    return jsonify({"ok": True, "score": 0, "solved": 0})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
