(() => {
  "use strict";

  const state = {
    challenges: [],
    email: null,
    score: 0,
    solved: new Set(),
    category: "All",
    search: "",
  };

  const $ = (selector) => document.querySelector(selector);
  const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  function showToast(message, bad = false) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.toggle("bad", bad);
    toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => {
      toast.hidden = true;
    }, 4200);
  }

  function setScore(score, solvedCount, total) {
    state.score = score;
    $("#stat-score").textContent = score;
    $("#stat-solved").textContent = solvedCount;
    $(".score-chip").textContent = `${score} pts`;
    $("#progress-text").textContent = `${solvedCount} of ${total} captured`;
    $("#progress-fill").style.width = total ? `${(solvedCount / total) * 100}%` : "0%";
  }

  function updateEmail() {
    $("#email-button").textContent = state.email || "Enter your email";
    $("#progress-email").textContent = state.email
      ? `Results for ${state.email}`
      : "No email recorded yet.";
  }

  function openModal() {
    $("#email-modal").hidden = false;
    $("#email-error").textContent = "";
    $("#email-input").value = state.email || "";
    setTimeout(() => $("#email-input").focus(), 50);
  }

  function closeModal() {
    $("#email-modal").hidden = true;
  }

  function endpointHref(port) {
    const protocol = location.protocol === "https:" ? "https:" : "http:";
    return `${protocol}//${location.hostname}:${port}/`;
  }

  function wireEndpoints() {
    document.querySelectorAll("[data-port]").forEach((anchor) => {
      anchor.href = endpointHref(anchor.dataset.port);
      anchor.target = "_blank";
      anchor.rel = "noreferrer";
    });
  }

  async function getJson(url, options) {
    const response = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `request failed (${response.status})`);
    return body;
  }

  async function loadAll() {
    const [catalog, profile] = await Promise.all([
      getJson("/api/challenges"),
      getJson("/api/profile"),
    ]);
    state.challenges = catalog.challenges;
    state.email = profile.email;
    state.solved = new Set(catalog.challenges.filter((c) => c.solved).map((c) => c.id));
    setScore(catalog.score, catalog.solved, catalog.challenges.length);
    updateEmail();
    renderFilters();
    renderChallenges();
    $("#stat-total").textContent = state.challenges.length;
    if (!state.email) openModal();
  }

  function renderFilters() {
    const container = $("#category-filters");
    const categories = ["All", ...new Set(state.challenges.map((c) => c.category))];
    container.replaceChildren();
    categories.forEach((category) => {
      const button = el("button", "chip", category);
      button.type = "button";
      button.classList.toggle("active", state.category === category);
      button.addEventListener("click", () => {
        state.category = category;
        renderFilters();
        renderChallenges();
      });
      container.append(button);
    });
  }

  function renderChallenges() {
    const container = $("#challenges");
    const query = state.search.toLowerCase();
    const visible = state.challenges.filter((challenge) => {
      if (state.category !== "All" && challenge.category !== state.category) return false;
      if (!query) return true;
      return [
        challenge.title,
        challenge.category,
        challenge.summary,
        challenge.objective,
        challenge.tool.join(" "),
        String(challenge.number),
      ]
        .join(" ")
        .toLowerCase()
        .includes(query);
    });

    container.replaceChildren();
    if (!visible.length) {
      container.append(el("div", "loading", "No challenges match that filter."));
      return;
    }

    visible.forEach((challenge) => {
      const solved = state.solved.has(challenge.id);
      const card = el("article", `card${solved ? " solved" : ""}`);
      card.dataset.challenge = challenge.id;

      const top = el("div", "card-top");
      top.append(el("div", "num", String(challenge.number).padStart(2, "0")));
      const heading = el("div");
      heading.append(el("h3", "", challenge.title));
      top.append(heading);
      card.append(top);

      card.append(el("p", "", challenge.summary));
      card.append(el("p", "objective", challenge.objective));

      const meta = el("div", "meta");
      meta.append(el("span", `pill ${challenge.difficulty}`, challenge.difficulty));
      meta.append(el("span", "pill points", `${challenge.points} pts`));
      meta.append(el("span", "pill", challenge.category));
      challenge.tool.forEach((tool) => meta.append(el("span", "pill tool", tool)));
      card.append(meta);

      const hint = el("details", "hint");
      hint.append(el("summary", "", "Need a nudge?"));
      hint.append(el("p", "", challenge.hint));
      card.append(hint);

      const feedback = el("div", "feedback");
      card.append(feedback);

      if (solved) {
        card.append(el("div", "answer solved-box", "✓ flag accepted"));
      } else {
        const form = el("form", "answer");
        const input = el("input");
        input.type = "text";
        input.name = "answer";
        input.placeholder = challenge.answer_hint || "CG{...}";
        input.autocomplete = "off";
        input.spellcheck = false;
        const button = el("button", "", "SUBMIT");
        button.type = "submit";
        form.append(input, button);
        form.addEventListener("submit", async (event) => {
          event.preventDefault();
          if (!state.email) {
            openModal();
            feedback.className = "feedback bad";
            feedback.textContent = "enter your email first";
            return;
          }
          const answer = input.value.trim();
          if (!answer) return;
          button.disabled = true;
          feedback.className = "feedback";
          feedback.textContent = "checking…";
          try {
            const result = await getJson("/api/submit", {
              method: "POST",
              body: JSON.stringify({ challenge_id: challenge.id, answer }),
            });
            if (result.correct) {
              state.solved.add(challenge.id);
              feedback.className = "feedback ok";
              feedback.textContent = result.already_solved
                ? "already captured"
                : `+${result.points} points`;
              card.classList.add("solved");
              if (!result.already_solved) {
                form.replaceWith(el("div", "answer solved-box", "✓ flag accepted"));
                showToast(`Flag accepted: ${challenge.title} (+${result.points})`);
              }
              await loadAll();
            } else {
              feedback.className = "feedback bad";
              feedback.textContent = result.message || "not accepted";
            }
          } catch (error) {
            feedback.className = "feedback bad";
            feedback.textContent = error.message;
          } finally {
            button.disabled = false;
          }
        });
        card.append(form);
      }

      container.append(card);
    });
  }

  $("#email-button").addEventListener("click", openModal);
  $("#modal-close").addEventListener("click", closeModal);
  $("#email-modal").addEventListener("click", (event) => {
    if (event.target === $("#email-modal") && state.email) closeModal();
  });

  $("#email-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = $("#email-input").value.trim();
    const error = $("#email-error");
    error.textContent = "";
    try {
      await getJson("/api/profile", {
        method: "POST",
        body: JSON.stringify({ email }),
      });
      closeModal();
      await loadAll();
      showToast(`Results will be labelled ${state.email}`);
    } catch (requestError) {
      error.textContent = requestError.message;
    }
  });

  $("#export-button").addEventListener("click", () => {
    if (!state.email) {
      openModal();
      return;
    }
    window.location.assign("/api/export");
  });

  $("#reset-button").addEventListener("click", async () => {
    if (!state.email) {
      openModal();
      return;
    }
    if (!window.confirm("Clear all captured flags and points, keeping your email?")) return;
    try {
      await getJson("/api/reset", { method: "POST" });
      showToast("Local progress cleared");
      await loadAll();
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("#search").addEventListener("input", (event) => {
    state.search = event.target.value.trim();
    renderChallenges();
  });

  wireEndpoints();
  loadAll().catch((error) => {
    $("#challenges").replaceChildren(el("div", "loading", `Could not load challenges: ${error.message}`));
  });
})();
