#!/usr/bin/env bash
# Kubernetes Cloud Goat CTF lifecycle wrapper.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

CLUSTER="${CLUSTER:-cloudgoat}"
CTX="kind-${CLUSTER}"
COMPOSE="docker compose"
KUBECTL=(kubectl --context "$CTX")

log() { printf '\033[1;36m[*]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

need() {
  command -v "$1" >/dev/null 2>&1 || die "missing '$1'. Run ./scripts/install-tools.sh or install it manually."
}

require_docker() {
  need docker
  docker info >/dev/null 2>&1 || die "Docker is not running or this user cannot access the daemon."
  $COMPOSE version >/dev/null 2>&1 || die "Docker Compose v2 is required."
}

generate() {
  python3 scripts/generate.py "$@"
}

build_images() {
  set -a
  # shellcheck disable=SC1091
  source generated/build.env
  set +a

  log "Building lab images"
  docker build -t cloudgoat/lab-app:latest apps/lab-app
  docker build \
    --build-arg "AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}" \
    --build-arg "AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}" \
    --build-arg "SENSITIVE_KEYS=${SENSITIVE_KEYS}" \
    -t cloudgoat/build-code:latest apps/build-code
  docker build \
    --build-arg "AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}" \
    --build-arg "AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}" \
    --build-arg "TRIVY_IMAGE=${TRIVY_IMAGE:-not-used}" \
    --build-arg "LAYERS=${LAYERS}" \
    -t cloudgoat/leaky-app:latest apps/leaky-app

  log "Loading images into kind"
  kind load docker-image cloudgoat/lab-app:latest --name "$CLUSTER"
  kind load docker-image cloudgoat/build-code:latest --name "$CLUSTER"
  kind load docker-image cloudgoat/leaky-app:latest --name "$CLUSTER"
}

ensure_cluster() {
  need kind
  need kubectl
  if kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
    log "kind cluster '$CLUSTER' already exists"
  else
    log "Creating kind cluster '$CLUSTER'"
    kind create cluster --config kind-config.yaml --name "$CLUSTER" --wait 5m
  fi
  kubectl --context "$CTX" get nodes
}

wait_localstack() {
  log "Waiting for LocalStack"
  for _ in $(seq 1 60); do
    if curl -fsS http://127.0.0.1:4566/_localstack/health >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  die "LocalStack did not become healthy"
}

seed_cloud() {
  log "Seeding local AWS account"
  $COMPOSE run --rm --build cloud-seed
}

apply_lab() {
  log "Applying namespaces and flags"
  "${KUBECTL[@]}" apply -f k8s/00-namespaces.yaml
  "${KUBECTL[@]}" apply -f generated/k8s-secrets.yaml
  log "Applying RBAC"
  "${KUBECTL[@]}" apply -f k8s/10-rbac.yaml
  log "Applying workloads"
  "${KUBECTL[@]}" apply -f k8s/20-apps.yaml
  "${KUBECTL[@]}" apply -f k8s/30-workloads.yaml
  "${KUBECTL[@]}" apply -f k8s/40-audit.yaml

  log "Writing node-side flags"
  ./generated/node-flags.sh "${CLUSTER}-control-plane"

  log "Waiting for workloads"
  for ns in cloudgoat big-monolith billing; do
    "${KUBECTL[@]}" wait --for=condition=available --timeout=180s deployment --all -n "$ns" >/dev/null || true
  done
  "${KUBECTL[@]}" wait --for=condition=Ready --timeout=120s pod/falco-target -n cloudgoat >/dev/null 2>&1 || true
  "${KUBECTL[@]}" wait --for=condition=Ready --timeout=120s pod/tetragon-target -n cloudgoat >/dev/null 2>&1 || true
}

print_access() {
  cat <<EOF

  Kubernetes Cloud Goat CTF is up.

  CTF portal       http://127.0.0.1:8000
  Vulnerable app   http://127.0.0.1:30080
  Private registry http://127.0.0.1:30085/v2/_catalog
  LocalStack       http://127.0.0.1:4566

  kube context     ${CTX}
  AWS profile      cloudgoat (endpoint http://127.0.0.1:4566)

  Enter your email in the portal, then download results when finished.
  Progress is stored locally in data/ctf.db. No teams.
  Useful checks:    ./lab.sh status

  All listeners are on 127.0.0.1. Do not expose them to an untrusted network.
EOF
}

cmd_up() {
  require_docker
  if [[ ! -f flags/flags.json ]]; then
    generate
  fi
  if [[ ! -f generated/build.env ]]; then
    generate
  fi

  log "Starting LocalStack and CTF portal"
  $COMPOSE up -d --build localstack ctf
  wait_localstack
  seed_cloud
  python3 scripts/aws_profile.py

  ensure_cluster
  build_images
  apply_lab

  print_access
}

cmd_down() {
  require_docker
  log "Stopping Compose services"
  $COMPOSE down --remove-orphans || true
  if command -v kind >/dev/null 2>&1 && kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
    log "Deleting kind cluster '$CLUSTER'"
    kind delete cluster --name "$CLUSTER"
  fi
  log "Lab is down. Flags and generated files were kept; use './lab.sh purge' to remove them."
}

cmd_reset() {
  require_docker
  log "Regenerating flags and credentials"
  generate --reset
  rm -f data/ctf.db data/ctf.db-shm data/ctf.db-wal
  python3 scripts/aws_profile.py

  if ! kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
    ensure_cluster
  fi
  build_images
  apply_lab

  log "Restarting workloads to pick up new flags"
  for ns in cloudgoat big-monolith billing; do
    "${KUBECTL[@]}" rollout restart deployment -n "$ns" >/dev/null 2>&1 || true
  done

  log "Restarting LocalStack and reseeding"
  $COMPOSE up -d --build localstack ctf
  wait_localstack
  seed_cloud

  print_access
  warn "Local progress was stored server-side in data/ctf.db (removed)."
}

cmd_status() {
  require_docker
  $COMPOSE ps || true
  if command -v kubectl >/dev/null 2>&1; then
    "${KUBECTL[@]}" get nodes -o wide || true
    "${KUBECTL[@]}" get pods -A -o wide || true
    "${KUBECTL[@]}" get svc -A || true
  fi
}

cmd_flags() {
  [[ -f flags/answers.md ]] || die "no flags yet; run ./lab.sh up"
  cat flags/answers.md
}

cmd_urls() {
  print_access
}

cmd_seed() {
  require_docker
  wait_localstack
  seed_cloud
}

cmd_aws_profile() {
  python3 scripts/aws_profile.py
}

cmd_purge() {
  cmd_down || true
  rm -rf flags/flags.json flags/answers.md generated/*.yaml generated/*.env generated/node-flags.sh \
    data/ctf.db data/ctf.db-shm data/ctf.db-wal data/localstack
  log "Removed generated flags, manifests, CTF database, and LocalStack data."
}

case "${1:-help}" in
  up) cmd_up ;;
  down) cmd_down ;;
  reset) cmd_reset ;;
  status) cmd_status ;;
  flags|answers) cmd_flags ;;
  urls) cmd_urls ;;
  seed) cmd_seed ;;
  aws-profile) cmd_aws_profile ;;
  purge) cmd_purge ;;
  help|-h|--help)
    cat <<EOF
Usage: ./lab.sh <command>

  up            Generate flags, build images, create kind, deploy, seed cloud
  down          Delete the kind cluster and stop Compose services
  reset         New flags + rebuild + redeploy + reseed (clears CTF scores)
  status        Show Compose and Kubernetes status
  flags         Print the instructor answer key (do not show participants)
  urls          Print the local URLs
  seed          Re-run the LocalStack seed
  aws-profile   Write the 'cloudgoat' AWS profile to ~/.aws
  purge         down + remove generated flags, manifests, scores and cloud data

Environment:
  CLUSTER       kind cluster name (default: cloudgoat)
EOF
    ;;
  *) die "unknown command: $1 (try ./lab.sh help)" ;;
esac
