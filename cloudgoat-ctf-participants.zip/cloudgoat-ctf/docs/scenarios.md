# Scenario reference

This guide describes where each challenge's answer lives. It does **not**
include flag values. The authoritative public metadata is
`challenges/catalog.json`; the instructor answer key is `flags/answers.md`.

Challenges 01–22 mirror the Kubernetes Goat scenarios. Challenges 23–25 add
CloudFox, Grype, and Trivy exercises.

| # | Challenge | Category | Tools | Pts | Where to look |
| --- | --- | --- | --- | --- | --- |
| 01 | Sensitive keys in a codebase | Secrets | gitleaks, trivy, git | 100 | Deleted `.env` in the `build-code` pod's `/app/.git` history. |
| 02 | DIND: the runtime socket is in the pod | Runtime | kubectl | 150 | Privileged `health-check` pod; `/host-runtime` and `/host-flags` mounts. |
| 03 | SSRF into the cluster network | Network | curl, kubectl | 100 | `internal-proxy` `/fetch?url=...` reaching `metadata-db:8080/secret`. |
| 04 | Privileged pod, host filesystem | Runtime | kubectl | 200 | `system-monitor` pod with hostPath `/`; node flag under `/host-system/var/lib/cloudgoat/`. |
| 05 | Docker CIS benchmark: root user | Audit | trivy | 75 | `trivy config apps/docker-cis`; submit the root-user check ID. |
| 06 | Kubernetes CIS: baseline violation | Audit | trivy, kube-bench | 100 | Trivy PSS baseline report; flag in the `cis-target` deployment env. |
| 07 | Unauthenticated private registry | Supply Chain | curl, skopeo | 100 | NodePort 30085 catalog and the image config `Env` entry. |
| 08 | NodePort exposes an internal API | Network | curl, kubectl | 75 | `http://127.0.0.1:30080/status` leaks the workload environment. |
| 09 | Legacy Helm v2 Tiller | Legacy | kubectl, helm | 100 | Simulated `tiller-deploy` pod; flag in its environment. |
| 10 | Crypto miner in the cluster | Runtime | kubectl, falco | 75 | Anomalous `crypto-miner` workload; flag in its environment. |
| 11 | Namespace bypass via cluster-wide RBAC | RBAC | kubectl | 125 | `dev:developer` can read `prod/db-credentials` via a ClusterRoleBinding. |
| 12 | Gaining environment information | Secrets | kubectl, curl | 100 | `env-app` `/env` endpoint; also exposes AWS credentials. |
| 13 | DoS: no requests or limits | Runtime | kubectl | 75 | `hunger-check` deployment in `big-monolith`; flag in `dos-flag` Secret. |
| 14 | Hacker container / pod creation | RBAC | kubectl | 150 | `pod-creator` ServiceAccount and the `hacker-loot` Secret. |
| 15 | Hidden in image layers | Supply Chain | skopeo, trivy | 125 | Registry image history: a secret is created and then deleted. |
| 16 | RBAC least privilege: cluster-admin for a workload | RBAC | kubectl | 150 | `kube-system:superadmin` is cluster-admin; `goat-admin-flag` Secret. |
| 17 | KubeAudit: audit the cluster | Audit | kubeaudit, kubectl | 100 | `audit-target` deployment; flag in its environment. |
| 18 | Falco: suspicious runtime behavior | Runtime | falco, kubectl | 100 | Privileged hostPID `falco-target` pod; flag in its environment. |
| 19 | Popeye: cluster sanitizer | Audit | popeye, kubectl | 100 | `popeye-target` deployment; flag in its environment. |
| 20 | No network boundaries | Network | kubectl, curl | 125 | Missing NetworkPolicies; SSRF reaches `billing-api.billing.svc`. |
| 21 | Tetragon: observe a hostPID workload | Runtime | tetragon, kubectl | 100 | Privileged hostPID `tetragon-target` pod; flag in its environment. |
| 22 | Kyverno: a policy violator | Policy | kyverno, kubectl | 100 | `policy-violator` deployment with a privileged securityContext. |
| 23 | CloudFox: follow the leaked AWS key | Cloud | cloudfox, aws | 200 | LocalStack S3 object `prod/cloudfox.flag` in the public backups bucket. |
| 24 | Grype: known vulnerable dependencies | Supply Chain | grype, trivy | 100 | Any High/Critical CVE or GHSA reported for `cloudgoat/leaky-app:latest`. |
| 25 | Trivy: secret in the image | Secrets | trivy | 100 | AWS access key ID baked into `/app/.env` in `cloudgoat/leaky-app`. |

## Kubernetes namespaces

| Namespace | Contents |
| --- | --- |
| `cloudgoat` | Most vulnerable workloads, RBAC identities, registry, proxy, audit targets |
| `big-monolith` | `hunger-check` deployment and its flag Secret |
| `billing` | `billing-api` and the network-policy flag |
| `prod` | `db-credentials` Secret used by the namespace-bypass challenge |
| `dev` | `developer` ServiceAccount with cluster-wide secret read |
| `kube-system` | `superadmin` ServiceAccount and cluster-admin flag Secret |

## Ports

| Port | Service |
| --- | --- |
| 30080 | NodePort for `nodeport-info-service` (public console) |
| 30085 | NodePort for the toy registry |
| 8000 | CTF portal |
| 4566 | LocalStack |
| 1232 / 1237 | Common participant port-forwards for proxy and env-app |

## Answer format

- Most answers are `CG{...}` strings and are validated by SHA-256 hash.
- Challenge 05 expects the Trivy Dockerfile check ID.
- Challenge 24 accepts `CVE-YYYY-NNNNN` or `GHSA-XXXX-XXXX-XXXX` from a
  High/Critical Grype finding.
- Challenge 25 expects the `AKIA...` access key ID, not the secret key.

Answers are case-insensitive for regex challenges and whitespace is stripped
before checking.
