# Coverage and limitations

## Kubernetes Goat scenarios

The lab covers all 22 Kubernetes Goat scenarios in the instructor's tracking
list. Each scenario has a dedicated challenge, workload, and generated flag.

| Kubernetes Goat scenario | Challenge | Implementation |
| --- | --- | --- |
| Sensitive keys in codebase | 01 | Git repo in `build-code` image with a deleted `.env` |
| DIND | 02 | Privileged `health-check` pod mounting containerd socket and host directory |
| SSRF | 03 | `internal-proxy` with an unrestricted `/fetch?url=` fetcher |
| Container escape | 04 | Privileged `system-monitor` with hostPath `/` and hostPID |
| Docker CIS | 05 | Trivy scan of `apps/docker-cis/Dockerfile` |
| Kubernetes CIS | 06 | Trivy PSS baseline compliance report plus a violating deployment |
| Registry | 07 | Unauthenticated toy OCI registry on NodePort 30085 |
| NodePort | 08 | Internally-intended API published on NodePort 30080, leaking env |
| Tiller | 09 | Simulated legacy Tiller console with no authentication |
| Crypto miner | 10 | Idle `crypto-miner` workload with a wallet env var |
| Namespace bypass | 11 | ClusterRoleBinding allowing `dev:developer` to read `prod` secrets |
| Env info | 12 | `env-app` `/env` returning the full process environment |
| DoS | 13 | `hunger-check` with no requests or limits |
| Hacker container | 14 | `pod-creator` ServiceAccount able to create pods and read loot |
| Hidden layers | 15 | Toy registry image history with created/deleted secret |
| RBAC | 16 | `kube-system:superadmin` bound to `cluster-admin` |
| KubeAudit | 17 | `audit-target` with insecure settings and a flag |
| Falco | 18 | Privileged hostPID `falco-target` representing an escape event |
| Popeye | 19 | `popeye-target` with missing probes and weak security context |
| Network policy | 20 | No NetworkPolicies; cross-namespace SSRF to billing API |
| Tetragon | 21 | Privileged hostPID `tetragon-target` for runtime observation |
| Kyverno | 22 | `policy-violator` breaching a restricted privilege policy |

## Additional tooling challenges

| Challenge | Tool | What is real |
| --- | --- | --- |
| 23 CloudFox | CloudFox + AWS CLI | CloudFox enumerates a real LocalStack account through a `cloudgoat` AWS profile with `endpoint_url` set; buckets, IAM users, and Secrets Manager data are seeded. |
| 24 Grype | Grype | Grype scans the real locally built `cloudgoat/leaky-app:latest` image and reports genuine package/OS findings. |
| 25 Trivy | Trivy | Trivy's secret scanner finds the real baked-in AWS credential in the image; participants extract the file to read the masked value. |

Gitleaks is exercised in challenge 01 against a real Git repository with a
deleted secret in history.

## What is genuinely vulnerable

- **Kubernetes**: kind runs a real API server, scheduler, controller manager,
  kubelet, and CoreDNS. RBAC, hostPath mounts, privileged containers, hostPID,
  NodePorts, and resource limits are real Kubernetes behavior.
- **Images**: `lab-app`, `build-code`, and `leaky-app` are built locally with
  Docker and loaded into kind. Scanners inspect the same images participants can
  inspect on the host.
- **Cloud**: LocalStack provides real IAM, S3, STS, Secrets Manager, and SQS
  APIs. The provided AWS profile works with the AWS CLI and CloudFox.
- **CTF**: scoring is real. Flags are hashed before the portal sees them;
  plaintext values stay in `flags/flags.json` and Kubernetes Secrets.

## What is simulated or intentionally limited

- **Toy registry**: `apps/lab-app` implements a small read-only subset of the
  OCI distribution API. It serves two prebuilt manifests so registry and layer
  challenges work without pushing images during setup.
- **Tiller**: represented by a simple Flask console, not Helm v2.
- **Security tools as observers**: Falco, Tetragon, Kyverno, kubeaudit, Popeye,
  and kube-bench are installed on Kali, not as controllers in the cluster. The
  lab supplies vulnerable target workloads for them to inspect.
- **No real exploit impact**: the miner is idle, the DoS workload does not
  attack anything, host mounts are read-only where a write is not required, and
  the escape stops at the kind node container.
- **LocalStack community**: ECR is not implemented and is skipped during seed.
  CloudFox may emit errors for unsupported services or regions.
- **Loopback only**: all ports bind to `127.0.0.1`. This is a single-machine
  workshop, not a shared network range.

## Tool versions used during validation

The lab was validated with Docker 29, kind 0.33, kubectl 1.34, Trivy, Grype
0.122, Gitleaks 8.30, CloudFox 2.0.5, Skopeo, and AWS CLI v2 against LocalStack
3.8.1. The installer in `scripts/install-tools.sh` fetches current versions on
Kali, so exact scanner output may vary.
