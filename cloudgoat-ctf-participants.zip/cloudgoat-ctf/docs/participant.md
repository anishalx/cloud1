# Kubernetes Cloud Goat CTF — Participant Guide

You are working alone on your own local lab: one Kali machine, one kind cluster,
one LocalStack account, and one CTF portal database. Progress is personal to
that lab: there are no teams and no shared scoreboard. You enter your email once
before starting so the instructor can identify your results; that email and your
progress stay in this local lab until you download them.

> [!WARNING]
> The cluster is intentionally insecure: privileged pods, host mounts,
> cluster-admin service accounts, leaked credentials, an open registry, and no
> network policies. Keep every service bound to `127.0.0.1` and never reuse the
> generated credentials.

## Your lab at a glance

| Service | Address |
| --- | --- |
| CTF portal | `http://127.0.0.1:8000` |
| Public console | `http://127.0.0.1:30080` |
| Toy registry | `http://127.0.0.1:30085/v2/_catalog` |
| LocalStack | `http://127.0.0.1:4566` |
| Kubernetes context | `kind-cloudgoat` |
| AWS profile | `cloudgoat` |

Set the Kubernetes context once so the commands in this guide work without
`--context` on every line:

```bash
kubectl config use-context kind-cloudgoat
```

Check the local cloud identity:

```bash
export AWS_PROFILE=cloudgoat
aws sts get-caller-identity
```

## Enter your email, track progress, and submit

Open `http://127.0.0.1:8000`. The portal asks for your email before any flags
can be submitted. Use the address the instructor expects: it labels your
downloaded results. You can change it later with the **Enter your email** button.

The same steps are available through the API:

```bash
curl -H 'Content-Type: application/json' \
  -d '{"email":"you@example.com"}' \
  http://127.0.0.1:8000/api/profile

curl -H 'Content-Type: application/json' \
  -d '{"challenge_id":"08-nodeport","answer":"CG{...}"}' \
  http://127.0.0.1:8000/api/submit

curl http://127.0.0.1:8000/api/me
```

Useful endpoints:

- `GET /api/profile` — the email currently recorded in this lab.
- `GET /api/challenges` — the 25 challenge definitions and your solved status.
- `GET /api/me` — your email, solved count, and score.
- `GET /api/results` — your email plus every solved challenge and timestamp.
- `GET /api/export` — download `cloudgoat-results.csv`.
- `POST /api/reset` — clear your local progress but keep your email.

At the end, click **Download results** in the portal and send the CSV to the
instructor. Submissions are limited to 40 per minute and each challenge awards
points once.

## How to read each activity

Every activity below has four parts:

1. **What the code does** — the exact vulnerable setting or application logic.
2. **How to find the vulnerability** — the investigation steps.
3. **Commands** — copy/paste starting points, with no answers.
4. **Reading the output** — how to tell that you found the right thing.

Take notes as you go. When an answer looks like `CG{...}`, submit exactly that
string. Three activities are different: challenge 05 wants a Trivy check ID,
challenge 24 wants a CVE/GHSA ID, and challenge 25 wants an AWS access key ID.

## Installing the tools (Docker is provided, not installed here)

Every participant runs their own isolated copy of the lab on their own Kali
machine. Docker Engine and the Compose v2 plugin must already be running; this
guide verifies them but deliberately does **not** install or change Docker.

```bash
# Prerequisite check only - no installation
docker info
docker compose version
```

If either command fails, install/start Docker on Kali before continuing.

### One-command participant installer

From the project directory:

```bash
cd cloudgoat-ctf
./scripts/install-participant-tools.sh
```

The script is idempotent: tools that are already present are left alone. It
uses `sudo` automatically when you are not root.

### What that installer adds, and why each tool matters

| Tool | Used for | What the installer does |
| --- | --- | --- |
| `git`, `curl`, `wget`, `jq`, `unzip`, `tar`, `make`, `ca-certificates` | Copying Git histories, calling APIs, parsing JSON, extracting releases | Installs the base Kali packages. |
| `python3`, `python3-pip` | Optional CTF API examples | Installs Python 3 and pip. |
| `skopeo` | Reading registry manifests and image config/history | Installed from Kali packages. |
| `helm` (`kubernetes-helm`) | Context for the legacy Tiller challenge | Installed from Kali packages. |
| AWS CLI v2 | Verifying the `cloudgoat` profile and copying the S3 flag | Downloads the official x86_64 or aarch64 bundle and installs it to `/usr/local/bin`. |
| `kind` | Creating the local Kubernetes cluster | Downloads kind v0.33.0 for amd64 or arm64. |
| `kubectl` | Inspecting pods, RBAC, secrets, and port-forwarding | Downloads the current stable client for amd64 or arm64. |
| `trivy` | Dockerfile, image-secret, and Kubernetes compliance scans | Uses the Kali package when available, otherwise the official install script. |
| `grype` | Vulnerable-package scanning | Uses the official install script. |
| `gitleaks` | Secret scanning of Git history | Downloads the latest GitHub release tarball. |
| `cloudfox` | Enumerating the local AWS environment | Downloads the latest GitHub release zip. |
| `kubeaudit` | Auditing Kubernetes manifests for insecure settings | Downloads the latest GitHub release tarball. |
| `popeye` | Reporting unhealthy/unsanitized cluster objects | Downloads the latest GitHub release tarball. |
| `kube-bench` | CIS Kubernetes benchmark checks | Downloads the latest GitHub release tarball. |

### Verify the installation

```bash
for tool in docker kind kubectl trivy grype gitleaks cloudfox \
            kubeaudit popeye kube-bench helm skopeo aws jq; do
  printf '%-12s ' "$tool"
  "$tool" --version 2>/dev/null | head -1 || true
done
```

All tools except Docker should report a version. `cloudfox --version` may print
only a short banner. If `aws` hangs or prints an old Python traceback, remove the
broken binary and reinstall AWS CLI v2 with the commands in the installer.

### Start your own lab

```bash
./lab.sh up
./lab.sh status
./lab.sh urls
```

This creates a cluster named `cloudgoat`, a kubeconfig context named
`kind-cloudgoat`, an AWS profile named `cloudgoat`, and the CTF database in your
project directory. Because everything binds to `127.0.0.1`, multiple people can
run identical labs on separate machines without port conflicts. Do not share the
CTF database or the generated flags.

## 01 — Sensitive keys in a codebase

**Category:** Secrets  
**Points:** 100  
**Tools:** `gitleaks`, `trivy`, `git`

**Objective:** Recover the flag from the deleted .env file in the build-code repository.

### What the code does

The `build-code` image contains a real `.git` directory under `/app`. Its
Dockerfile writes a `.env` file with AWS credentials and the challenge flag,
commits it, then runs `git rm .env` and makes a second commit. That second commit
only removes the file from the working tree. Git is a content-addressed object
database: the blob from the first commit is still reachable from the commit
history, so `git log --all -p` can print it again. Gitleaks automates the
discovery by scanning every commit (`--log-opts=--all`) for high-entropy keys.

### How to find the vulnerability

Inspect the running pod, copy its Git metadata to your Kali machine, scan it
with Gitleaks, then walk the full history to read the deleted file. The first
commit message is a strong clue.

### Commands

```bash
POD=$(kubectl -n cloudgoat get pods -l app=build-code \
  -o jsonpath='{.items[0].metadata.name}')
rm -rf /tmp/build-code-git
kubectl -n cloudgoat cp "$POD:/app/.git" /tmp/build-code-git

gitleaks detect --source /tmp/build-code-git --log-opts=--all \
  --report-format json --report-path /tmp/gitleaks.json
jq -r '.[] | [.RuleID, .Commit, .File] | @tsv' /tmp/gitleaks.json

git -C /tmp/build-code-git log --all --oneline
git -C /tmp/build-code-git log --all -p -- .env
```

### Reading the output

Gitleaks reports a `generic-api-key` finding and points to the commit that
introduced `.env`. `git log --all --oneline` shows two commits: one adding the
service and local credentials, one removing `.env`. `git log --all -p -- .env`
reprints the removed lines, including `CLOUDGOAT_FLAG=...`. The AWS key in the
same file is useful later in challenge 23, but this challenge wants the flag.

## 02 — DIND: the runtime socket is in the pod

**Category:** Runtime  
**Points:** 150  
**Tools:** `kubectl`

**Objective:** Find the mounted runtime socket and read the flag from the host-mounted directory.

### What the code does

The `health-check` deployment sets `hostPID: true`, `privileged: true`, and
mounts two host paths: `/run/containerd` at `/host-runtime` and
`/var/lib/cloudgoat` at `/host-flags`. Access to the containerd socket is
effectively root on the node: an attacker can list, start, and inspect
containers outside their own pod. The application's `/runtime` route lists the
mounted directories, confirming the exposure.

### How to find the vulnerability

Start from the pod spec. Look for `privileged`, `hostPID`, `hostPath`, and
`volumeMounts`. Then list the mounted directories from inside the pod and use
the HTTP helper to confirm which host paths are present.

### Commands

```bash
kubectl -n cloudgoat get pod -l app=health-check -o yaml
POD=$(kubectl -n cloudgoat get pods -l app=health-check \
  -o jsonpath='{.items[0].metadata.name}')
kubectl -n cloudgoat exec "$POD" -- sh -c \
  'ls -la /host-runtime /host-flags; ls -l /host-runtime/containerd.sock'

kubectl -n cloudgoat port-forward svc/health-check-service 1234:80
# In another terminal:
curl -s http://127.0.0.1:1234/runtime | jq .
kubectl -n cloudgoat exec "$POD" -- sh -c 'for f in /host-flags/*; do echo "== $f"; cat "$f"; done'
```

### Reading the output

The YAML is the proof: a container in the `cloudgoat` namespace can see the
node's container runtime and a host-side flag directory. The `/runtime` JSON
shows `/host-runtime`, `/host-flags`, and `/host-system` as mounted paths. The
file under `/host-flags` contains this challenge's flag.

## 03 — SSRF into the cluster network

**Category:** Network  
**Points:** 100  
**Tools:** `curl`, `kubectl`

**Objective:** Use the proxy to reach the internal metadata service and recover its flag.

### What the code does

The `internal-proxy` app exposes `/fetch?url=...`. It checks only that the URL
scheme is `http` or `https`, then calls Python's `urlopen` with no allowlist,
no blocklist, and no metadata-address protection. Because the pod runs inside
the cluster, Kubernetes DNS resolves names such as `metadata-db` and
`billing-api.billing.svc.cluster.local`. The proxy page even lists those
internal targets. This is a textbook server-side request forgery (SSRF).

### How to find the vulnerability

Port-forward the proxy service, call `/fetch` without a URL to read its usage
note, then request the listed internal metadata endpoint. Compare that with a
direct request from your Kali machine, which cannot resolve cluster DNS.

### Commands

```bash
kubectl -n cloudgoat port-forward svc/internal-proxy-service 1232:80
# In another terminal:
curl -s http://127.0.0.1:1232/ | jq .
curl -s http://127.0.0.1:1232/fetch
curl -s 'http://127.0.0.1:1232/fetch?url=http://metadata-db:8080/secret' | jq .
curl -s 'http://127.0.0.1:1232/fetch?url=http://kubernetes.default.svc/api' | head
```

### Reading the output

The bare `/fetch` response says the proxy accepts any URL, including cluster
DNS names. The response from `metadata-db:8080/secret` is JSON with a `flag`
field and a note that the service should not have been reachable. That note is
your confirmation that the SSRF crossed an intended boundary.

## 04 — Privileged pod, host filesystem

**Category:** Runtime  
**Points:** 200  
**Tools:** `kubectl`

**Objective:** Read the node flag through the hostPath mount.

### What the code does

The `system-monitor` pod is privileged and mounts the node root filesystem
`/` at `/host-system` with `readOnly: true`. Read-only does not protect
confidentiality: the process can still read every file the pod's privileges
allow. The app's `/host-tree` route openly suggests a flag path under
`/var/lib/cloudgoat`, turning a real container-escape-style misconfiguration
into a guided exercise.

### How to find the vulnerability

Read the deployment YAML for privileged mode and hostPath. Use the HTTP
helper for the suggested path, then read that path from inside the pod.

### Commands

```bash
kubectl -n cloudgoat get deploy system-monitor -o yaml | grep -A12 -E 'privileged|hostPath|mountPath'
POD=$(kubectl -n cloudgoat get pods -l app=system-monitor \
  -o jsonpath='{.items[0].metadata.name}')
kubectl -n cloudgoat port-forward svc/system-monitor-service 1235:8080
# In another terminal:
curl -s http://127.0.0.1:1235/host-tree | jq .
kubectl -n cloudgoat exec "$POD" -- sh -c \
  'cat /host-system/var/lib/cloudgoat/node.flag'
```

### Reading the output

The manifest shows `privileged: true` and a hostPath volume at `/`. The
`/host-tree` response names the exact file. Being able to read a node file from
a workload namespace demonstrates why hostPath mounts should be forbidden by
policy (Kyverno/PSS) in real clusters.

## 05 — Docker CIS benchmark: root user

**Category:** Audit  
**Points:** 75  
**Tools:** `trivy`

**Objective:** Scan the Dockerfile and submit the Trivy check ID for the root-user finding.

### What the code does

The Dockerfile under `apps/docker-cis` starts from `python:3.11-slim`, runs
`apt-get` as root, copies the app, and never adds a `USER` instruction. The
final image therefore runs its main process as UID 0. Trivy's Dockerfile
scanner maps this to a Docker CIS check ID (the report shows it as `DS-0002`,
also accepted as `DS002`). This activity teaches mapping a scanner result back
to a hardening control.

### How to find the vulnerability

Read the Dockerfile and look for the absence of `USER`. Then run Trivy's
config/Dockerfile scanner and read the check ID next to the root-user finding.

### Commands

```bash
cat apps/docker-cis/Dockerfile
trivy config apps/docker-cis
```

### Reading the output

The report lists a finding whose title describes running as root or using the
default root user. The ID in the ID column is the answer. Unlike other
activities, there is no `CG{...}` string here: you submit the check ID itself.

## 06 — Kubernetes CIS: baseline violation

**Category:** Audit  
**Points:** 100  
**Tools:** `trivy`, `kube-bench`

**Objective:** Use a cluster compliance scan to find the offending workload and read its flag.

### What the code does

The `cis-target` deployment deliberately breaks Pod Security Standards: it is
privileged, uses host namespaces or host ports, and mounts host paths. Trivy's
Kubernetes compliance scanner evaluates live objects against the PSS baseline
profile and reports which controls fail. The flag is stored in the workload
environment, so the audit result tells you which deployment to inspect.

### How to find the vulnerability

Run the compliance report with the lab's context. Note the failing controls,
then inspect `cis-target` and read its environment variables.

### Commands

```bash
trivy k8s kind-cloudgoat \
  --compliance k8s-pss-baseline-0.1 \
  --report summary --skip-images --disable-node-collector

kubectl -n cloudgoat get deploy cis-target -o yaml
kubectl -n cloudgoat exec deploy/cis-target -- sh -c 'env | sort'
```

### Reading the output

The compliance table shows FAIL for controls such as Privileged Containers,
Host Namespaces, HostPath Volumes, and Host Ports. The `cis-target` YAML
corresponds to those failures. Its `env` section contains a flag-valued
variable; use that value to submit.

## 07 — Unauthenticated private registry

**Category:** Supply Chain  
**Points:** 100  
**Tools:** `curl`, `skopeo`

**Objective:** Enumerate the registry and inspect the image configuration for the flag.

### What the code does

The registry on NodePort 30085 implements a small read-only OCI distribution
API with no authentication and no TLS. OCI registries expose a catalog
endpoint, manifests, and config blobs. Image config blobs include an `Env`
array from the original build. This lab baked a flag into one image's
configuration, so simply reading the config leaks it.

### How to find the vulnerability

Enumerate the catalog, then use Skopeo to read the config of each repository.
`--tls-verify=false` is required because the registry serves plain HTTP.

### Commands

```bash
curl -s http://127.0.0.1:30085/v2/_catalog | jq .
skopeo inspect --tls-verify=false --config \
  docker://127.0.0.1:30085/cloudgoat/leaky-app:latest | jq .
skopeo inspect --tls-verify=false --config \
  docker://127.0.0.1:30085/cloudgoat/hidden-layers:latest | jq '.config.Env'
```

### Reading the output

The catalog lists two repositories. The `leaky-app` config contains an `Env`
entry with a `CG{...}` value. The `hidden-layers` config is useful in challenge
15. An unauthenticated registry is a supply-chain exposure: anyone who can
reach the port can read metadata and pull images.

## 08 — NodePort exposes an internal API

**Category:** Network  
**Points:** 75  
**Tools:** `curl`, `kubectl`

**Objective:** Reach the service from outside the cluster and recover the exposed flag.

### What the code does

The `nodeport-info-service` is exposed through NodePort 30080. Its
`nodeport` application mode makes `/status` add `body["env"] = dict(os.environ)`.
That debug behaviour would be acceptable only on a trusted internal port, but
NodePort publishes the service on every node interface. Environment variables
often hold database URLs and credentials, so this is a common real-world leak.

### How to find the vulnerability

Start with the browser at `http://127.0.0.1:30080`, then request `/status` and
inspect the `env` object. No Kubernetes credentials are needed.

### Commands

```bash
curl -s http://127.0.0.1:30080/status | jq .
curl -s http://127.0.0.1:30080/status | jq -r '.env | to_entries[] | [.key,.value] | @tsv'
```

### Reading the output

The JSON contains normal fields such as pod, namespace, and node, plus an
`env` object with the full process environment. One variable is the flag. The
lesson is to avoid publishing internal services with NodePort and to never
return `os.environ` from an HTTP endpoint.

## 09 — Legacy Helm v2 Tiller

**Category:** Legacy  
**Points:** 100  
**Tools:** `kubectl`, `helm`

**Objective:** Find the tiller-deploy workload and retrieve the flag from its environment.

### What the code does

Helm v2 used a cluster-side component called Tiller that accepted release
requests without meaningful authentication and often ran with broad cluster
permissions. This lab represents that risk with a `tiller-deploy` pod and an
unauthenticated HTTP console. Its environment also carries the flag, because
legacy add-ons were commonly granted secrets through environment variables.

### How to find the vulnerability

Locate the workload, inspect its deployment for the image and environment,
then port-forward its service and view the console.

### Commands

```bash
kubectl -n cloudgoat get deploy tiller-deploy -o yaml
kubectl -n cloudgoat exec deploy/tiller-deploy -- sh -c 'env | grep -i flag'
kubectl -n cloudgoat port-forward svc/tiller-deploy 1236:8080
# In another terminal:
curl -s http://127.0.0.1:1236/ | jq .
```

### Reading the output

The environment listing reveals the flag. The console demonstrates that no
authentication stands between a caller and a component that historically could
install arbitrary charts with cluster privileges.

## 10 — Crypto miner in the cluster

**Category:** Runtime  
**Points:** 75  
**Tools:** `kubectl`, `falco`

**Objective:** Identify the miner workload and recover the flag from its environment.

### What the code does

Crypto-mining incidents often appear as an unexpected deployment with an
odd image name, a wallet address, and high CPU. This lab's `crypto-miner`
workload is deliberately suspicious but idle: it sleeps instead of actually
mining. The objective is practising workload triage, not crypto mining.

### How to find the vulnerability

List deployments and their images, look for names that do not match the
application inventory, then describe and inspect the suspicious workload.

### Commands

```bash
kubectl -n cloudgoat get deployments \
  -o custom-columns='NAME:.metadata.name,IMAGE:.spec.template.spec.containers[0].image'
kubectl -n cloudgoat describe deploy crypto-miner
kubectl -n cloudgoat exec deploy/crypto-miner -- sh -c 'env | grep -iE "flag|wallet|pool"'
```

### Reading the output

The image and deployment name stand out among normal services. The
environment contains a wallet-like value and the challenge flag. In a real
incident you would also check resource usage, process lists, and the image's
provenance.

## 11 — Namespace bypass via cluster-wide RBAC

**Category:** RBAC  
**Points:** 125  
**Tools:** `kubectl`

**Objective:** Prove the cross-namespace access and recover the flag from prod/db-credentials.

### What the code does

The `developer` ServiceAccount lives in `dev`, but a ClusterRole named
`cloudgoat-secret-reader` grants `get` and `list` on secrets, and a
ClusterRoleBinding applies it across the whole cluster. RBAC is additive: a
namespaced identity can therefore read secrets in `prod`, even though the
developer has no role there. ClusterRoleBindings are a common source of
accidental privilege escalation.

### How to find the vulnerability

Check what the ServiceAccount can do in another namespace with
`kubectl auth can-i --as`, then read the `prod` secret using impersonation.

### Commands

```bash
kubectl get clusterrolebinding cloudgoat-developer-secret-reader -o yaml
kubectl auth can-i --list \
  --as=system:serviceaccount:dev:developer -n prod
kubectl get secrets -n prod --as=system:serviceaccount:dev:developer
kubectl get secret db-credentials -n prod \
  --as=system:serviceaccount:dev:developer \
  -o jsonpath='{.data.flag}' | base64 -d; echo
```

### Reading the output

`auth can-i` returns `yes` for secrets in `prod`. The ClusterRoleBinding is
the root cause: it binds a namespaced identity to a cluster-wide permission. The
decoded `flag` key of `db-credentials` is the answer.

## 12 — Gaining environment information

**Category:** Secrets  
**Points:** 100  
**Tools:** `kubectl`, `curl`

**Objective:** Reach the env-app endpoint and recover the flag.

### What the code does

The `env-app` workload runs the lab app with `APP_MODE=env`. In that mode the
`/env` route returns `dict(os.environ)` as JSON. Debug endpoints like this are
frequently left enabled in production, and environment variables frequently
contain API keys, database passwords, and cloud credentials.

### How to find the vulnerability

Port-forward the service, inspect the page for hints, then call `/env` and
search the JSON for flag and AWS-related keys.

### Commands

```bash
kubectl -n cloudgoat get deploy env-app -o yaml
kubectl -n cloudgoat port-forward svc/env-app 1237:8000
# In another terminal:
curl -s http://127.0.0.1:1237/ | jq .
curl -s http://127.0.0.1:1237/env | jq .
curl -s http://127.0.0.1:1237/env | \
  jq -r 'to_entries[] | select(.key|test("FLAG|AWS"; "i")) | [.key,.value] | @tsv'
```

### Reading the output

The JSON includes a flag variable and fake AWS credentials. The credentials
are intentionally scoped to LocalStack and are also used in challenge 23. The
security lesson is that environment dumps are credential dumps.

## 13 — DoS: no requests or limits

**Category:** Runtime  
**Points:** 75  
**Tools:** `kubectl`

**Objective:** Inspect the resource configuration and recover the flag.

### What the code does

The `hunger-check` deployment in `big-monolith` has no
`resources.requests` or `resources.limits`. Without requests, the scheduler
does not reserve capacity; without limits, one container can consume a node's
CPU or memory and starve neighbours. The flag is kept in a Secret in the same
namespace so the exercise also covers namespace-scoped secret discovery.

### How to find the vulnerability

Inspect the deployment for a missing `resources` block, then list and read
Secrets in `big-monolith`.

### Commands

```bash
kubectl -n big-monolith get deploy hunger-check -o yaml
kubectl -n big-monolith describe deploy hunger-check | grep -iA4 -E 'limits|requests' || true
kubectl -n big-monolith get secrets
kubectl -n big-monolith get secret dos-flag \
  -o jsonpath='{.data.flag}' | base64 -d; echo
```

### Reading the output

The absence of a `resources` section confirms the DoS precondition. The
`dos-flag` Secret holds this challenge's flag. In production, apply LimitRanges
and ResourceQuotas so every namespace has defaults.

## 14 — Hacker container / pod creation

**Category:** RBAC  
**Points:** 150  
**Tools:** `kubectl`

**Objective:** Use the ServiceAccount permissions to locate the loot secret and recover the flag.

### What the code does

The `pod-creator` ServiceAccount is bound to a Role that lets it create pods
and read a Secret named `hacker-loot` in `cloudgoat`. Pod creation is a powerful
privilege: an attacker can schedule a container with a mounted ServiceAccount
token, hostPath, or privileged mode. This challenge focuses on enumerating what
the identity can access.

### How to find the vulnerability

Use `auth can-i --as` to map the ServiceAccount's permissions, then read the
secret it is allowed to access.

### Commands

```bash
kubectl get role cloudgoat-pod-creator -n cloudgoat -o yaml
kubectl auth can-i --list \
  --as=system:serviceaccount:cloudgoat:pod-creator -n cloudgoat
kubectl get secret hacker-loot -n cloudgoat \
  --as=system:serviceaccount:cloudgoat:pod-creator \
  -o jsonpath='{.data.flag}' | base64 -d; echo
```

### Reading the output

The Role lists `create` on pods and `get` on secrets. Reading `hacker-loot`
with the impersonated identity returns the flag. In a real compromise, pod
creation can be escalated further by mounting more privileged identities.

## 15 — Hidden in image layers

**Category:** Supply Chain  
**Points:** 125  
**Tools:** `skopeo`, `trivy`

**Objective:** Inspect the image history and recover the deleted secret.

### What the code does

Container images are stacks of layers. The `hidden-layers` image history has
one instruction that writes a secret and a later instruction that deletes it.
Deleting a file in a new layer records a whiteout; it does not erase the bytes
from the earlier layer. Anyone who can read the image config or layers can
recover what was removed.

### How to find the vulnerability

Inspect the image config with Skopeo and read the `history[].created_by`
strings. Look for the `RUN` instruction that created the file.

### Commands

```bash
skopeo inspect --tls-verify=false --config \
  docker://127.0.0.1:30085/cloudgoat/hidden-layers:latest \
  | jq -r '.history[].created_by'
trivy image --scanners secret \
  cloudgoat/hidden-layers:latest 2>/dev/null || true
```

### Reading the output

The history shows a command creating a flag file followed by a command
removing it. The flag value remains in the earlier layer's command or file. This
is why secrets must never be baked into images, even temporarily.

## 16 — RBAC least privilege: cluster-admin for a workload

**Category:** RBAC  
**Points:** 150  
**Tools:** `kubectl`

**Objective:** Confirm the blast radius and recover the flag from a kube-system secret.

### What the code does

The ServiceAccount `superadmin` in `kube-system` is a subject of the built-in
`cluster-admin` ClusterRole through `cloudgoat-superadmin`. That role grants
wildcard verbs on wildcard resources, effectively cluster root. A workload
using this ServiceAccount can read every Secret, including `goat-admin-flag`.

### How to find the vulnerability

Inspect the ClusterRoleBinding, list permissions via impersonation, then read
the Secret in `kube-system`.

### Commands

```bash
kubectl get clusterrolebinding cloudgoat-superadmin -o yaml
kubectl auth can-i --list --as=system:serviceaccount:kube-system:superadmin
kubectl get secret goat-admin-flag -n kube-system \
  --as=system:serviceaccount:kube-system:superadmin \
  -o jsonpath='{.data.flag}' | base64 -d; echo
```

### Reading the output

The binding references `ClusterRole/cluster-admin`. `auth can-i --list`
shows `*` for resources and verbs. Decoding `goat-admin-flag` yields the flag.
The fix is least privilege: bind only the exact verbs a workload needs.

## 17 — KubeAudit: audit the cluster

**Category:** Audit  
**Points:** 100  
**Tools:** `kubeaudit`, `kubectl`

**Objective:** Run kubeaudit, identify audit-target, and recover its flag.

### What the code does

The `audit-target` deployment intentionally uses privileged mode, a root
user, and weak security settings. KubeAudit inspects live objects or manifests
and reports these issues. The insecure pod also carries the flag in its
environment, linking the audit finding to a concrete workload.

### How to find the vulnerability

Run KubeAudit against the lab namespace, compare its findings with the
target's YAML, then read the target's environment.

### Commands

```bash
kubeaudit all --namespace cloudgoat
kubectl -n cloudgoat get deploy audit-target -o yaml
kubectl -n cloudgoat exec deploy/audit-target -- sh -c 'env | grep -i flag'
```

### Reading the output

KubeAudit prints warnings about privileged containers, runAsRoot, missing
read-only root filesystems, or similar controls. The matching deployment's
environment contains the flag. Treat audit output as a to-do list for
hardening, not as an end in itself.

## 18 — Falco: suspicious runtime behavior

**Category:** Runtime  
**Points:** 100  
**Tools:** `falco`, `kubectl`

**Objective:** Identify the runtime-escape workload and recover the flag.

### What the code does

Falco is a runtime security tool that alerts on behaviour such as spawning a
shell in a container, writing to sensitive paths, or using `nsenter` from a
hostPID pod. The `falco-target` pod is privileged and shares the host PID
namespace, exactly the kind of workload a Falco rule would flag. The lab does
not install Falco as an admission controller; the pod itself carries the flag.

### How to find the vulnerability

Inspect the pod spec for `hostPID` and `privileged`, look at the host process
list from inside the pod to confirm the shared namespace, then read its
environment.

### Commands

```bash
kubectl -n cloudgoat get pod falco-target -o yaml
kubectl -n cloudgoat exec falco-target -- sh -c 'ps aux | head -20'
kubectl -n cloudgoat exec falco-target -- sh -c 'env | grep -i flag'
```

### Reading the output

Seeing host processes from a workload confirms `hostPID: true`. A real Falco
deployment would emit alerts for namespace-escape commands from such a pod. The
environment variable found inside it is this challenge's answer.

## 19 — Popeye: cluster sanitizer

**Category:** Audit  
**Points:** 100  
**Tools:** `popeye`, `kubectl`

**Objective:** Run Popeye, find popeye-target, and recover its flag.

### What the code does

Popeye scans live clusters for unsanitized objects: missing probes, missing
resource limits, privileged containers, deprecated APIs, and similar hygiene
issues. `popeye-target` is deliberately unhealthy. The Pod Spec tells you what
Popeye would report, and the environment holds the flag.

### How to find the vulnerability

Run Popeye across all namespaces, find the target in its report, inspect the
deployment, then read the environment.

### Commands

```bash
popeye -A
kubectl -n cloudgoat get deploy popeye-target -o yaml
kubectl -n cloudgoat exec deploy/popeye-target -- sh -c 'env | grep -i flag'
```

### Reading the output

Popeye flags the target for missing liveness/readiness probes and weak
security context. The corresponding deployment's environment contains the flag.
Popeye is an audit aid; fixing the findings is the actual hardening work.

## 20 — No network boundaries

**Category:** Network  
**Points:** 125  
**Tools:** `kubectl`, `curl`

**Objective:** Use the SSRF proxy to reach the cross-namespace billing API and recover its flag.

### What the code does

By default, Kubernetes allows pod-to-pod and namespace-to-namespace traffic.
There are no NetworkPolicy objects in the lab, so the SSRF proxy in `cloudgoat`
can call `billing-api.billing.svc.cluster.local` directly. The billing service
returns a flag from `/secret`, and the same flag is stored in the `billing-flag`
Secret. NetworkPolicies are the control that would deny this path.

### How to find the vulnerability

Confirm that no NetworkPolicies exist, then reuse the proxy from challenge 03
with the billing service URL. The Secret is an alternate source.

### Commands

```bash
kubectl get networkpolicies -A
kubectl -n cloudgoat port-forward svc/internal-proxy-service 1238:80
# In another terminal:
curl -s 'http://127.0.0.1:1238/fetch?url=http://billing-api.billing.svc.cluster.local:8080/secret' | jq .
kubectl -n billing get secret billing-flag \
  -o jsonpath='{.data.flag}' | base64 -d; echo
```

### Reading the output

The empty NetworkPolicy list confirms the missing boundary. The proxy's
response includes the billing flag, proving that namespace names are not
security boundaries. A default-deny NetworkPolicy plus explicit allows would
stop this traffic.

## 21 — Tetragon: observe a hostPID workload

**Category:** Runtime  
**Points:** 100  
**Tools:** `tetragon`, `kubectl`

**Objective:** Find tetragon-target and recover its flag.

### What the code does

Tetragon uses eBPF to observe process and network events at the kernel level.
A privileged pod with `hostPID` is exactly what an eBPF runtime policy would
watch for exec events outside the container's expected behaviour. The lab's
`tetragon-target` represents that pattern and carries the flag in its
environment; no eBPF controller is installed in the cluster.

### How to find the vulnerability

Check the pod spec for host namespaces and privilege, inspect running
processes from the pod, then read its environment.

### Commands

```bash
kubectl -n cloudgoat get pod tetragon-target -o yaml
kubectl -n cloudgoat exec tetragon-target -- sh -c 'ps -ef | head -20'
kubectl -n cloudgoat exec tetragon-target -- sh -c 'env | grep -i flag'
```

### Reading the output

The shared PID namespace makes host processes visible, which a runtime
observation tool would treat as suspicious. The environment variable inside the
pod is the answer. Runtime visibility complements, but does not replace,
preventive controls like PSS and admission policies.

## 22 — Kyverno: a policy violator

**Category:** Policy  
**Points:** 100  
**Tools:** `kyverno`, `kubectl`

**Objective:** Find policy-violator and recover its flag.

### What the code does

Kyverno is a Kubernetes policy engine that can reject or flag workloads which
violate rules such as Pod Security Standards. `policy-violator` runs a
privileged container and would be blocked by a restricted policy. No Kyverno
controller is installed here, so the cluster accepts the bad pod; the flag is
in its environment.

### How to find the vulnerability

Look for any installed policies, inspect the deployment's securityContext,
then read its environment.

### Commands

```bash
kubectl get clusterpolicy,policy -A 2>/dev/null || true
kubectl -n cloudgoat get deploy policy-violator -o yaml
kubectl -n cloudgoat exec deploy/policy-violator -- sh -c 'env | grep -i flag'
```

### Reading the output

No policies exist to reject the privileged pod. The `securityContext` shows
`privileged: true`, and the environment contains the flag. In a hardened
cluster, a Kyverno validate policy would enforce `runAsNonRoot`, drop
capabilities, and forbid privilege escalation.

## 23 — CloudFox: follow the leaked AWS key

**Category:** Cloud  
**Points:** 200  
**Tools:** `cloudfox`, `aws`

**Objective:** Use CloudFox with the leaked credentials to enumerate the local AWS account and recover the S3 flag.

### What the code does

The AWS credentials found earlier are fake but valid against LocalStack. The
`cloudgoat` AWS profile points the AWS CLI and CloudFox at
`http://127.0.0.1:4566`. CloudFox enumerates services and produces loot files
that can contain bucket names, secrets, and ready-to-run commands. The flag is
stored as an S3 object in a public backups bucket.

### How to find the vulnerability

Verify the profile with STS, run the CloudFox `buckets` and `secrets` checks,
then use the AWS CLI to list and copy the discovered object.

### Commands

```bash
export AWS_PROFILE=cloudgoat
aws sts get-caller-identity
cloudfox aws --profile cloudgoat buckets
cloudfox aws --profile cloudgoat secrets
find ~/.cloudfox/cloudfox-output -type f | tail -20

aws s3 ls
aws s3 ls s3://cloudgoat-public-backups/prod/
aws s3 cp s3://cloudgoat-public-backups/prod/cloudfox.flag -
```

### Reading the output

STS shows a LocalStack identity, not a real AWS account. CloudFox's tables
list the seeded bucket and the Secrets Manager secret. Copying the S3 object
prints the flag. This is the same workflow an attacker follows after finding
leaked keys: enumerate identity, services, buckets, and secrets.

## 24 — Grype: known vulnerable dependencies

**Category:** Supply Chain  
**Points:** 100  
**Tools:** `grype`, `trivy`

**Objective:** Run Grype and submit any CVE or GHSA it reports as High or Critical for cloudgoat/leaky-app:latest.

### What the code does

The `leaky-app` image pins old Python packages and an old Debian base. Grype
matches package versions against vulnerability feeds and reports CVE or GHSA
identifiers with severities. This activity teaches turning a scanner finding
into a reportable vulnerability ID, rather than simply looking for a flag.

### How to find the vulnerability

Run Grype in table mode, then use JSON output and `jq` to isolate High and
Critical rows. Submit any ID from those rows.

### Commands

```bash
grype cloudgoat/leaky-app:latest -o table
grype cloudgoat/leaky-app:latest -o json > /tmp/grype.json
jq -r '.matches[]
  | select(.vulnerability.Severity == "High" or .vulnerability.Severity == "Critical")
  | [.vulnerability.Severity, .vulnerability.ID, .artifact.name] | @tsv' /tmp/grype.json
```

### Reading the output

Each row pairs a package with a vulnerability ID and severity. The checker
accepts either a `CVE-YYYY-NNNN` or a `GHSA-XXXX-XXXX-XXXX` value from a High or
Critical row. This mirrors real triage: identify the vulnerable dependency and
record the advisory that tracks it.

## 25 — Trivy: secret in the image

**Category:** Secrets  
**Points:** 100  
**Tools:** `trivy`

**Objective:** Scan the image with Trivy and submit the leaked access key ID.

### What the code does

A `.env` file was copied into the `leaky-app` image during `docker build`.
Image layers are distributed with the image, so deleting the file in a later
stage would not remove it. Trivy's secret scanner detects the AWS access key
pattern but masks the value in its report. To recover it, read the file from the
image itself.

### How to find the vulnerability

Run Trivy's secret scanner to locate the file, then start a throwaway
container with `cat` as its entrypoint to print the file contents.

### Commands

```bash
trivy image --scanners secret cloudgoat/leaky-app:latest
docker run --rm --entrypoint cat cloudgoat/leaky-app:latest /app/.env
```

### Reading the output

Trivy names `/app/.env` and shows a masked `AKIA...` value. The `docker run`
output shows the full file. Submit only the access key ID, not the secret access
key. This closes the loop with challenge 23: one leaked key enables cloud
enumeration.

## Troubleshooting

- **A pod is `ImagePullBackOff`.** Images are built on the host and loaded into
  kind by `./lab.sh up`. Re-run `./lab.sh up`.
- **`kubectl` cannot connect.** Run `kubectl config use-context kind-cloudgoat`
  and `./lab.sh status`.
- **`aws` hangs.** Use AWS CLI v2. The `cloudgoat` profile already contains
  `endpoint_url = http://127.0.0.1:4566`; you can also pass
  `--endpoint-url http://127.0.0.1:4566` explicitly.
- **CloudFox reports errors for unsupported services.** LocalStack community
  implements only part of AWS. The bucket and secret checks in the hints are the
  intended paths.
- **Skopeo complains about certificates.** The toy registry uses plain HTTP;
  keep `--tls-verify=false` in the commands.
- **A score does not appear.** Check that you entered your email, that you are
  using the portal from the same lab, strip trailing whitespace, and remember
  that regex answers are case-insensitive.
- **Submissions are rejected with "enter your email first."** Reload the portal
  and complete the email prompt, or call `POST /api/profile`.
- **You lost your flags.** Another participant cannot help: every lab has its
  own generated values. Run `./lab.sh reset` to start over with new ones.
