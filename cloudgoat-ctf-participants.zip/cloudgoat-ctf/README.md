# Kubernetes Cloud Goat CTF — Participant Lab

This is your own local copy of the workshop. Do not share it with other
participants: your flags, CTF progress, and LocalStack state are generated
inside this directory.

## Prerequisites

Kali Linux with Docker Engine and Docker Compose v2 already running. This
package verifies Docker but does not install it.

## Start

```bash
cd cloudgoat-ctf
./scripts/install-participant-tools.sh   # first time only
./lab.sh up
./lab.sh status
```

Then open <http://127.0.0.1:8000>. Enter your email before starting; there
are no teams. The portal tracks your own progress only. When you finish, click
**Download results** and send `cloudgoat-results.csv` to the instructor. Use
**Reset local progress** if you want a clean score in this lab.

## Your endpoints

- CTF portal: <http://127.0.0.1:8000>
- Vulnerable console: <http://127.0.0.1:30080>
- Private registry: <http://127.0.0.1:30085/v2/_catalog>
- LocalStack: <http://127.0.0.1:4566>
- Kubernetes context: `kind-cloudgoat`
- AWS profile: `cloudgoat`

## Guide

Read `docs/pdf/participant.pdf` for tool installation and detailed walkthroughs
of all 25 activities. `docs/pdf/scenarios.pdf` and `docs/pdf/coverage.pdf` are
also included.

## Safety

Everything binds to `127.0.0.1`. Keep it that way. The cluster is intentionally
insecure and must not be exposed to an untrusted network.

## Lifecycle

```bash
./lab.sh up       # generate your flags, build and start everything
./lab.sh down     # stop services and delete the kind cluster
./lab.sh reset    # new flags and a clean local score
./lab.sh status   # show service and pod status
./lab.sh urls     # print the local URLs
```
